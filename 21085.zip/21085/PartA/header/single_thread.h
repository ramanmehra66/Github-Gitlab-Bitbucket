// Optimize this function

#include <immintrin.h>

void singleThread(int N, int *matA, int *matB, int *output)
/*{
  assert( N>=4 and N == ( N &~ (N-1)));
  for(int rowA = 0; rowA < N; rowA +=2) {
    for(int colB = 0; colB < N; colB += 2){
      int sum = 0;
      for(int iter = 0; iter < N; iter++) 
      {
        sum += matA[rowA * N + iter] * matB[iter * N + colB];
        sum += matA[(rowA+1) * N + iter] * matB[iter * N + colB];
        sum += matA[rowA * N + iter] * matB[iter * N + (colB+1)];
        sum += matA[(rowA+1) * N + iter] * matB[iter * N + (colB+1)];
      }

      // compute output indices
      int rowC = rowA>>1;
      int colC = colB>>1;
      int indexC = rowC * (N>>1) + colC;
      output[indexC] = sum;
    }
  }
 } */
  
{
  	int *res = new int[N*N];
	__m256i vec_multi_res = _mm256_setzero_si256(); //Initialize vector to zero
	__m256i vec_mat1 = _mm256_setzero_si256(); //Initialize vector to zero
	__m256i vec_mat2 = _mm256_setzero_si256(); //Initialize vector to zero

	int i, j, k;
	for (i = 0; i < N; i++)
	{
	    for (k = 0; k < N; k++)
	    {
		//Stores one element in mat1 and use it in all computations needed before proceeding
		//Stores as vector to increase computations per cycle
		int temp = i*N +k;
		vec_mat1 = _mm256_set1_epi32(matA[temp]);

		for (j = 0; j < N; j += 8)
		{
		    int x = k*N + j;
		    int y = i*N + j;	
		    vec_mat2 = _mm256_loadu_si256((__m256i*)&matB[x]); //Stores row of second matrix (eight in each iteration)
		    vec_multi_res = _mm256_loadu_si256((__m256i*)&res[y]); //Loads the result matrix row as a vector
		    vec_multi_res = _mm256_add_epi32(vec_multi_res ,_mm256_mullo_epi32(vec_mat1, vec_mat2));//Multiplies the vectors and adds to the result vector
		    _mm256_storeu_si256((__m256i*) &res[y], vec_multi_res);
		}
	    }
	}
    
    for(i=0;i<N;i++)
    {
    	for(j=0;j<N;j++)
    	{   
    		output[(i>>1)*(N>>1) + (j>>1)] += res[i*N+j];
    	}
    }
} 
