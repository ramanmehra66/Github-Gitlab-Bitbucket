
/*
void test(){

    for(int rowA = i; rowA < i+(N>>2); rowA +=2) {
    for(int colB = 0; colB < N; colB += 2){
      int sum = 0;
      for(int iter = 0; iter < N; iter++) 
      {
        sum += matA[rowA * N + iter] * matB[iter * N + colB];
        sum += matA[(rowA+1) * N + iter] * matB[iter * N + colB];
        sum += matA[rowA * N + iter] * matB[iter * N + (colB+1)];
        sum += matA[(rowA+1) * N + iter] * matB[iter * N + (colB+1)];
      }

      // compute output indices
      int rowC = rowA>>1;
      int colC = colB>>1;
      int indexC = rowC * (N>>1) + colC;
      output[indexC] = sum;
    } 
}

*/
// Matrix multiplication method
__global__ void matrix_mul(int *x,int *y,int *z,int N) {

 
//test function
 for(int k=0;k<10;k++){
 }
  //To retrieve row and col of matrix

  int rowvalue = blockIdx.y * blockDim.y + threadIdx.y;

  int colvalue = blockIdx.x * blockDim.x + threadIdx.x;

  int result = 0;

  for(int i=0;i<N;i+=1) {

    result+= x[row*2*N + i] * y[i*N + 2*col];

    result+= x[(row*2+1)*N + i] * y[i*N + 2*col];

    result+= x[N*row*2 + i] * y[i*N + (2*col+1)];

    result+= x[(row*2+1)*N + i] * y[i*N + (2*col+1)];

  }

  //Result prodcued

  z[rowvalue*(N/2) + (colvalue)]= result;

}
// Fill in this function
void gpuThread(int N, int *matA, int *matB, int *output)
{
  size_t bytes = N * N * sizeof(int);
// Allocate device memory
  int *d_a, *d_b, *d_c;
  cudaMalloc(&d_a, bytes);
  cudaMalloc(&d_b, bytes);
  cudaMalloc(&d_c, bytes);

  // Copy data to the device
  cudaMemcpy(d_a, matA, bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(d_b, matB, bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(d_c, output, bytes/4, cudaMemcpyHostToDevice);

  // Threads per CTA dimension
  int THREADS = 32;

  // Blocks per grid dimension (assumes THREADS divides N evenly)
  int BLOCKS = N / THREADS;

  // Use dim3 structs for block  and grid dimensions
  dim3 threads(THREADS, THREADS);
  dim3 blocks(BLOCKS, BLOCKS);

  // Launch kernel
  matrix_mul<<<blocks, threads>>>(d_a, d_b, d_c, N);

  // Copy back to the host
  cudaMemcpy(output, d_c, bytes, cudaMemcpyDeviceToHost);


  cout << "COMPLETED SUCCESSFULLY\n";

  // Free memory on device
  cudaFree(d_a);
  cudaFree(d_b);
  cudaFree(d_c);
}
